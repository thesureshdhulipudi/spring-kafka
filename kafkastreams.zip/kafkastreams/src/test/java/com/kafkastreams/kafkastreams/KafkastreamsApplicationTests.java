package com.kafkastreams.kafkastreams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkastreamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
